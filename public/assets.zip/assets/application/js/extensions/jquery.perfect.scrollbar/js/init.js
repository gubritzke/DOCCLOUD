/* init */
function initPerfectScroll()
{
	$('.scroll').perfectScrollbar();
}

$(function(){
	initPerfectScroll();
});